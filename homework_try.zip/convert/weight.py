
def kg_to_gram(kg):
    return kg * 1000


def gram_to_kg(gram):
    return gram / 1000