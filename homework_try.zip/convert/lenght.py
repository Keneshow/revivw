
def metr_to_km(metr):
    return metr / 1000


def km_to_metr(km):
    return km * 1000