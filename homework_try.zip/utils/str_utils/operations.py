
def reverse_str(s):
    return s[::-1]