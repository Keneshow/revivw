
def square(x):
    return x ** 2
