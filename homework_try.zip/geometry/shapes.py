
def rectangle_perimeter(length, width):
    return 2 * (length + width)

def circle_perimeter(radius):
    import math
    return 2 * math.pi * radius

def triangle_perimeter(side1, side2, side3):
    return side1 + side2 + side3
