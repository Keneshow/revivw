
def bark():
    print("Woof! Woof!")
