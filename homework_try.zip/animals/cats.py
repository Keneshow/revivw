
def meow():
    print("Meow! Meow!")
