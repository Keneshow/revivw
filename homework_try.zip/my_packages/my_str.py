def split_(a):
    return a.split("")


def lower_(a):
    return a.lower()


def upper_(a):
    return a.upper()


def remove_(a):
    return a.remove()


def pop_(a):
    return a.pop()


def title_(a):
    return a.title()


def reverse_(a):
    return a.reverse()


def replace_(a):
    return a.replace()


def append_(a):
    return a.append()


def extend_(a):
    return a.extend()


def items_(a):
    return a.items()

