import random

def get_random_number():
    return random.randint(1, 100)
