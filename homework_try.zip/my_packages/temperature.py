
def cels_to_fahr(cels):
    return (cels * 1.8) + 32


def fahr_to_cels(fahr):
    return (fahr - 32) / 1.8