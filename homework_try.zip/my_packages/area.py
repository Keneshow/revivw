import  math


def circle_area(r):
    return math.pi * r ** 2

print(circle_area(5))

def square_area(a):
    return a ** 2

print(square_area(8))